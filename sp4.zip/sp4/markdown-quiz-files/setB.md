# Computer Science Fundamentals Quiz
1. Computer Science is the study of:
    - (x) True
    - ( ) False

2. The binary numeral system is the foundation of computing. Which programming language is commonly used for implementing computer algorithms?
    - ( ) Java
    - ( ) C++
    - (x) Python
    - ( ) Ruby

3. Sorting a list of names alphabetically is an example of which type of algorithm?
    - [ ] Clustering
    - [x] Sorting
    - [ ] Searching
    - [ ] Graph traversal

4. What is the primary purpose of an operating system in computer science?
    - ( ) Simulate natural disasters
    - (x) Manage hardware resources and provide services to applications
    - ( ) Generate random numbers
    - ( ) Control physical robots

5. In computer science, what is the purpose of a compiler?
    - ( ) Creating 3D graphics
    - (x) Translating high-level programming code into machine code
    - ( ) Simulating natural disasters
    - ( ) Analyzing financial data

6. What type of programming paradigm is commonly associated with languages like Haskell and Lisp?
    - ( ) Procedural programming
    - ( ) Object-oriented programming
    - (x) Functional programming
    - ( ) Imperative programming

7. Alan Turing, a key figure in computer science, is best known for:
    - ( ) Creating the first computer mouse
    - (x) His contributions to theoretical computation and the Turing Machine
    - ( ) Developing the first programming language
    - ( ) Designing the first microprocessor

8. Which data structure is efficient for searching, inserting, and deleting elements in constant time?
    - ( ) Linked List
    - ( ) Stack
    - (x) Hash Table
    - ( ) Binary Tree

9. In computer science, what is the purpose of a version control system like Git?
    - ( ) Optical Character Recognition
    - ( ) Object Classification and Recognition
    - ( ) Organized Computing Resources
    - (x) Managing and tracking changes in source code

10. What is the significance of the term "Big O notation" in computer science?
    - ( ) A measure of computer screen size
    - (x) A notation to describe the performance of an algorithm
    - ( ) A programming language
    - ( ) A data storage unit

# End of Computer Science Quiz - Thank You.