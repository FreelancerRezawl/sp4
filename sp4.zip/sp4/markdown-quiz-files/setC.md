# Mathematics for Computer Science Quiz

---
1. What is the result of multiplying two imaginary units (i and j)?
    - ( ) 1
    - ( ) -1
    - (x) -1 (i * j = -1)

2. In Boolean algebra, what is the result of the AND operation with inputs 1 and 0?
    - ( ) 1
    - ( ) 0
    - (x) 0 (1 AND 0 = 0)

3. The Fibonacci sequence is defined by the recurrence relation F(n) = F(n-1) + F(n-2) with initial conditions F(0) = 0 and F(1) = 1. What is the 7th Fibonacci number?
    - ( ) 8
    - ( ) 13
    - (x) 21

4. What is the value of π (pi) to two decimal places?
    - ( ) 3.14
    - ( ) 3.16
    - (x) 3.14 (approximate value)

5. In matrix multiplication, if matrix A is of size 2x3 and matrix B is of size 3x4, what is the resulting size of the product AB?
    - ( ) 2x4
    - (x) 2x4
    - ( ) 3x3

6. What is the sum of the angles in a triangle?
    - ( ) 90 degrees
    - (x) 180 degrees
    - ( ) 360 degrees

7. The logarithm with base 10 of 1000 is:
    - ( ) 1
    - ( ) 2
    - (x) 3

8. What is the value of the square root of 49?
    - ( ) 5
    - ( ) 6
    - (x) 7

9. If a function f(x) = 2x + 3, what is f(5)?
    - ( ) 10
    - (x) 13
    - ( ) 15

10. In combinatorics, how many ways can you arrange the letters in the word "MATHEMATICS"?
    - ( ) 362880
    - ( ) 720
    - (x) 3628800
